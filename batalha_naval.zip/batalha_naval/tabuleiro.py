from random import choice

opcoes = ['*', '']

batalha_naval = [
	[choice(opcoes), choice(opcoes), choice(opcoes), choice(opcoes)],
	[choice(opcoes), choice(opcoes), choice(opcoes), choice(opcoes)],
	[choice(opcoes), choice(opcoes), choice(opcoes), choice(opcoes)],
	[choice(opcoes), choice(opcoes), choice(opcoes), choice(opcoes)],
	[choice(opcoes), choice(opcoes), choice(opcoes), choice(opcoes)],
]